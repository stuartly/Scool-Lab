/*
	背景素材
*/
var app=new Vue({
	el:"#container",
	data:{
		usage_index:["学科","开放数据","学术新闻","关于我们"],
		usage_function:["智能检索","智能导读","智能报导"],
		scholar_info:{
			"基本信息":"JieTang（唐杰）；Tel:xxxxxxx；E-mail:xxx@tsinghua.edu.cn；Prize/Glory:xxx",
			"介绍":"My research interests include artificial intelligence, data mining, social networks , machine learning and knowledge graph, with an emphasis on designing new algorithms for mining social and knowledge networks.；I have been visiting scholar at Cornell University (working with Prof. John Hopcroft and Jon Kleinberg), University of Southampton (working with Dame Wendy Hall), KU Leuven (working with Marie-Francine Moens), University of Illinois at Urbana-Champaign (short term, working with Jiawei Han), Chinese University of Hong Kong (working with Jeffrey Yu), and Hong Kong University of Science and Technology (working with Qiong Luo).……",
			"论文":"《Name disambiguation in AMiner》；《Graph Contrastive Coding for Structural Graph Representation Pre-Training》……",
			"专利":"一种快速计算图节点相似度的方法；基于统一概率模型的个性化用户标签建模与推荐方法……",
			"项目":"统一的语义Web内容生成模型研究；大规模Web社会网络的动态建模与分析……",
			"合作偏好":"工程合作偏好度：17.8；科研合作偏好度：25.8；潜在合作领域：社交网络、知识图谱、社会影响……"
		},
		scholar_info_visual:{
			"教授-清华大学计算机科学与技术系":"./image/visual/照片.png",
			"研究领域":"./image/visual/研究领域.png",
			"作者统计":"./image/visual/作者统计.png"
		}
	}
})